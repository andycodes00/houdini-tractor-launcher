__version__="VERSION"

SPOOL_DIRECTORY="/mnt/shows/render/spool/tkr"
SPOOL_ROOT="/mnt/shows/render"
